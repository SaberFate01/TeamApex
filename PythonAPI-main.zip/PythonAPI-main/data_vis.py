import enum, datetime
import re
from flask import Blueprint, request, jsonify
from sqlalchemy import Enum, TIMESTAMP
from flask import Blueprint, request, jsonify
from sqlalchemy import Table, MetaData, Column, Integer, Date, insert
from sqlalchemy.sql import null
from database import get_pool, sql_result_to_json
from sqlalchemy import (
    insert,
    Table,
    MetaData,
    Column,
    Integer,
    DateTime,
    String,
    select,
    and_,
    or_,
)
from group_chat import *
from chat import *
from checkin import *


data_visual_blueprint = Blueprint("data_visual_blueprint", __name__)


def Merge(dict1, dict2, dict3):
    return dict1 | dict2 | dict3


@data_visual_blueprint.route("/data_visual/get", methods=["POST"])
def get_check_in():
    try:
        if "userid" not in request.json:
            raise KeyError()
    except KeyError as ke:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )
    if "to_time" in request.json and "from_time" not in request.json:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )
    elif "from_time" in request.json:
        if "to_time" in request.json:
            try:
                date_from = datetime.strptime(request.json["from_time"], "%Y-%m-%d")
                date_to = datetime.strptime(request.json["to_time"], "%Y-%m-%d")
                if datetime.now() < date_from or date_from > date_to:
                    raise ValueError
            except ValueError as err:
                return (
                    jsonify(
                        {"error_type": "Bad request", "error_description": str(err)}
                    ),
                    400,
                )
        else:
            try:
                datetime.strptime(request.json["from_time"], "%Y-%m-%d")
            except ValueError as err:
                return (
                    jsonify(
                        {"error_type": "Bad request", "error_description": str(err)}
                    ),
                    400,
                )
            request.json["to_time"] = str(date.today())

        check_in = get_average_across(
            request.json["userid"], request.json["from_time"], request.json["to_time"]
        )
        one_chat = get_one_interaction(
            request.json["userid"], request.json["from_time"], request.json["to_time"]
        )
        group_chat = get_group_interaction(
            request.json["userid"], request.json["from_time"], request.json["to_time"]
        )
        if len(check_in) == 0:
            check_in = {"Aggregate_Average": None}
        return jsonify(Merge(check_in, one_chat, group_chat))
    else:
        check_in = get_average(request.json["userid"])
        one_chat = get_one_interaction_single(request.json["userid"])
        group_chat = get_group_interaction_single(request.json["userid"])
        return jsonify(Merge(check_in, one_chat, group_chat))


if __name__ == "__main__":
    pass
