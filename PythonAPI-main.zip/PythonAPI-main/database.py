import datetime

import pymysql
import sqlalchemy
from flask import Blueprint, jsonify, request
from google.cloud.sql.connector import Connector, IPTypes

database_blueprint = Blueprint("database_blueprint", __name__)

INSTANCE_CONNECTION_NAME = "acoustic-cirrus-396009:australia-southeast1:apex-vi"
DB_USER = "root"
DB_PASS = "root"
DB_NAME = "users"


@database_blueprint.route("/database", methods=["POST"])
def query_database():
    try:
        query = request.json["query"]
    except Exception as e:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(e)}),
            400,
        )

    pool = get_pool()

    with pool.connect() as db_conn:
        try:
            execution = db_conn.execute(sqlalchemy.text(query))
            db_conn.commit()
        except Exception as e:
            return (
                jsonify({"error_type": "Bad query", "error_description": str(e)}),
                400,
            )

        try:
            results = execution.mappings().all()
        except sqlalchemy.exc.ResourceClosedError:
            return jsonify({})

        return jsonify(sql_result_to_json(results))


def get_pool():
    connector = Connector(IPTypes.PUBLIC)

    def getconn() -> pymysql.connections.Connection:
        conn: pymysql.connections.Connection = connector.connect(
            INSTANCE_CONNECTION_NAME,
            "pymysql",
            user=DB_USER,
            password=DB_PASS,
            db=DB_NAME,
        )
        return conn

    pool = sqlalchemy.create_engine(
        "mysql+pymysql://",
        creator=getconn,
        # ...
    )
    return pool


def sql_result_to_json(sql_result):
    results = []
    for sql_row in sql_result:
        row = {}
        for key, value in sql_row.items():
            row[key] = value
            if isinstance(value, datetime.date):
                row[key] = value.strftime("%Y/%m/%d %H:%M:%S")
        results.append(row)
    return results


def sql_result_to_json_cloud(sql_result):
    results = []
    for sql_row in sql_result:
        try:
            temp = []
            for i in sql_row:
                temp.append(i)
            # print(temp)
            return temp
            row = {}
            for key, value in sql_row.items():
                row[key] = value
                if isinstance(value, datetime.date):
                    row[key] = value.strftime("%Y/%m/%d %H:%M:%S")
            results.append(row)
        except AttributeError as e:
            print(sql_row)
            return [
                {
                    "userid": sql_row[0],
                    "q1": float(sql_row[1]),
                    "q2": float(sql_row[2]),
                    "q3": float(sql_row[3]),
                    "q4": float(sql_row[4]),
                    "q5": float(sql_row[5]),
                }
            ]
            # raise Exception(sql_row)
    return results
