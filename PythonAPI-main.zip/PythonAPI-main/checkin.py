import re
from decimal import *
from flask import Blueprint, request, jsonify
from sqlalchemy import Table, MetaData, Column, Integer, Date, insert
from flask import Blueprint, request, jsonify
import datetime
from sqlalchemy import text
from datetime import *
from sqlalchemy import (
    insert,
    Table,
    MetaData,
    Column,
    Integer,
    DateTime,
    String,
    select,
    func,
    and_,
    or_,
)

from sqlalchemy.sql import null

from database import get_pool, sql_result_to_json_cloud

from database import get_pool

checkin_blueprint = Blueprint("checkin_blueprint", __name__)

NUM_QUESTIONS = 24

self_checkin = Table(
    "self_checkin",
    MetaData(),
    Column("userid", Integer, primary_key=True),
    Column("date", Date, primary_key=True),
    Column("q1", Integer),
    Column("q2", Integer),
    Column("q3", Integer),
    Column("q4", Integer),
    Column("q5", Integer),
    Column("q6", Integer),
    Column("q7", Integer),
    Column("q8", Integer),
    Column("q9", Integer),
    Column("q10", Integer),
    Column("q11", Integer),
    Column("q12", Integer),
    Column("q13", Integer),
    Column("q14", Integer),
    Column("q15", Integer),
    Column("q16", Integer),
    Column("q17", Integer),
    Column("q18", Integer),
    Column("q19", Integer),
    Column("q20", Integer),
    Column("q21", Integer),
    Column("q22", Integer),
    Column("q23", Integer),
    Column("q24", Integer),
)


@checkin_blueprint.route("/checkin/post", methods=["POST"])
def post_checkin():
    missing_field = None
    if "userid" not in request.json:
        missing_field = "userid"
    elif "date" not in request.json:
        missing_field = "date"

    if missing_field is not None:
        return (
            jsonify(
                {
                    "error_type": "Bad request",
                    "error_description": f"Missing field {missing_field}",
                }
            ),
            400,
        )

    questions = {f"q{i}": 0 for i in range(1, NUM_QUESTIONS + 1)}
    for key, value in request.json.items():
        if re.search(r"^q\d+$", key) is not None:
            questions[key] = value

    row = {"userid": request.json["userid"], "date": request.json["date"]}
    row.update(questions)

    pool = get_pool()
    with pool.connect() as db_conn:
        try:
            db_conn.execute(insert(self_checkin).values(row))
            db_conn.commit()
        except Exception as e:
            return (
                jsonify({"error_type": "Bad query", "error_description": str(e)}),
                400,
            )

    return ""


@checkin_blueprint.route("/checkin/get", methods=["POST"])
def get_messages():
    try:
        if "userid" not in request.json:
            raise KeyError()
    except KeyError as ke:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )
    if "to_time" in request.json and "from_time" not in request.json:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )
    elif "from_time" in request.json:
        if "to_time" in request.json:
            try:
                date_from = datetime.strptime(request.json["from_time"], "%Y-%m-%d")
                date_to = datetime.strptime(request.json["to_time"], "%Y-%m-%d")
                if datetime.now() < date_from or date_from > date_to:
                    raise ValueError
            except ValueError as err:
                return (
                    jsonify(
                        {"error_type": "Bad request", "error_description": str(err)}
                    ),
                    400,
                )
        else:
            try:
                datetime.strptime(request.json["from_time"], "%Y-%m-%d")
            except ValueError as err:
                return (
                    jsonify(
                        {"error_type": "Bad request", "error_description": str(err)}
                    ),
                    400,
                )
            request.json["to_time"] = str(date.today())
        return jsonify(
            get_average_across(
                request.json["userid"],
                request.json["from_time"],
                request.json["to_time"],
            )
        )
    else:
        return jsonify(get_average(request.json["userid"]))


# SELECT userid, AVG(q1), AVG(q2),AVG(q3),AVG(q4),AVG(q5) FROM self_checkin WHERE userid = 1;
def get_average(userid):
    pool = get_pool()
    with pool.connect() as db_conn:
        # query='SELECT userid, AVG(q1) as q1, AVG(q2) as q2,AVG(q3) as q3,AVG(q4) as q4,AVG(q5) as q5 FROM self_checkin WHERE userid = {};'.format(userid)
        query = (
            select(
                self_checkin.c.userid,
                func.avg(self_checkin.c.q1).label("q1"),
                func.avg(self_checkin.c.q2).label("q2"),
                func.avg(self_checkin.c.q3).label("q3"),
                func.avg(self_checkin.c.q4).label("q4"),
                func.avg(self_checkin.c.q5).label("q5"),
            )
            .where((self_checkin.c.userid == userid))
            .group_by(self_checkin.c.userid)
        )
        result = db_conn.execute((query))
        sql_row = sql_result_to_json_cloud(result)
        print("sql_row", sql_row)
        result = [
            {
                "userid": sql_row[0],
                "q1": float(sql_row[1]),
                "q2": float(sql_row[2]),
                "q3": float(sql_row[3]),
                "q4": float(sql_row[4]),
                "q5": float(sql_row[5]),
            }
        ]
        other_rows = {}
        for row in result:
            for j in row:
                if str(row["userid"]) == "None":
                    return {}
                if (type(row[j])) == type(Decimal(1)):
                    row[j] = float(row[j])
                elif str(type(row[j])) == "<class 'NoneType'>":
                    row[j] = 0
            id = row["userid"]
            if userid not in other_rows:
                other_rows[id] = [row]
            else:
                other_rows[id].append(row)

        final_result = []
        for otherValues, rows in other_rows.items():
            final_result.append(dict(UserID=otherValues, Values=rows))

        return dict(Aggregate_Average=final_result)


def get_average_across(userid, from_time, to_time):
    pool = get_pool()
    with pool.connect() as db_conn:
        # query='SELECT userid, AVG(q1) as q1, AVG(q2) as q2,AVG(q3) as q3,AVG(q4) as q4,AVG(q5) as q5 FROM self_checkin WHERE (userid = {} and (date between "{}" and "{}"));'.format(userid,from_time,to_time)
        query = (
            select(
                self_checkin.c.userid,
                func.avg(self_checkin.c.q1).label("q1"),
                func.avg(self_checkin.c.q2).label("q2"),
                func.avg(self_checkin.c.q3).label("q3"),
                func.avg(self_checkin.c.q4).label("q4"),
                func.avg(self_checkin.c.q5).label("q5"),
            )
            .where(
                (self_checkin.c.userid == userid)
                & (self_checkin.c.date.between(from_time, to_time))
            )
            .group_by(self_checkin.c.userid)
        )
        result = db_conn.execute((query))
        sql_row = sql_result_to_json_cloud(result)
        print("sql_row", sql_row)
        result = [
            {
                "userid": sql_row[0],
                "q1": float(sql_row[1]),
                "q2": float(sql_row[2]),
                "q3": float(sql_row[3]),
                "q4": float(sql_row[4]),
                "q5": float(sql_row[5]),
            }
        ]
        other_rows = {}
        for row in result:
            for j in row:
                if str(row["userid"]) == "None":
                    return {}
                if (type(row[j])) == type(Decimal(1)):
                    row[j] = float(row[j])
                elif str(type(row[j])) == "<class 'NoneType'>":
                    row[j] = 0
            id = row["userid"]
            if userid not in other_rows:
                other_rows[id] = [row]
            else:
                other_rows[id].append(row)

        final_result = []
        for otherValues, rows in other_rows.items():
            final_result.append(dict(UserID=otherValues, Values=rows))

        return dict(Aggregate_Average=final_result)
