from flask import Flask

from database import database_blueprint
from events import events_blueprint
from chat import chat_blueprint
from group_chat import group_chat_blueprint
from GPT_database import GPT_database_blueprint
from checkin import checkin_blueprint
from data_vis import data_visual_blueprint

app = Flask(__name__)
app.register_blueprint(database_blueprint)
app.register_blueprint(events_blueprint)
app.register_blueprint(chat_blueprint)
app.register_blueprint(group_chat_blueprint)
app.register_blueprint(GPT_database_blueprint)
app.register_blueprint(checkin_blueprint)
app.register_blueprint(data_visual_blueprint)


if __name__ == "__main__":
    app.run()
