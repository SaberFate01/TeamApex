from flask import Blueprint, request, jsonify
from sqlalchemy import (
    insert,
    Table,
    MetaData,
    Column,
    Integer,
    func,
    DateTime,
    String,
    select,
    and_,
    or_,
)

from sqlalchemy.sql import null

from database import get_pool, sql_result_to_json, sql_result_to_json_cloud

chat_blueprint = Blueprint("chat_blueprint", __name__)

one_on_one_chat = Table(
    "one_on_one_chat",
    MetaData(),
    Column("senderID", Integer, primary_key=True),
    Column("recipientID", Integer, primary_key=True),
    Column("timestamp", DateTime(timezone=True), primary_key=True),
    Column("message", String),
    Column("eventID", Integer),
)


@chat_blueprint.route("/chat/send", methods=["POST"])
def send_message():
    try:
        senderID = request.json["senderID"]
        recipientID = request.json["recipientID"]
        timestamp = request.json["timestamp"]
    except KeyError as ke:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )

    if "message" in request.json:
        message = request.json["message"]
    else:
        message = null()
    if "eventID" in request.json:
        eventID = request.json["eventID"]
    else:
        eventID = null()

    pool = get_pool()
    with pool.connect() as db_conn:
        try:
            db_conn.execute(
                insert(one_on_one_chat).values(
                    dict(
                        senderID=senderID,
                        recipientID=recipientID,
                        timestamp=timestamp,
                        message=message,
                        eventID=eventID,
                    )
                )
            )
            db_conn.commit()
        except Exception as e:
            return (
                jsonify({"error_type": "Bad query", "error_description": str(e)}),
                400,
            )

    return ""


@chat_blueprint.route("/chat/get", methods=["POST"])
def get_messages():
    try:
        userID = request.json["userID"]
    except KeyError as ke:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )

    if "otherID" in request.json:
        otherID = request.json["otherID"]
        return jsonify(get_messages_for_user_and_other(userID, otherID))
    else:
        return jsonify(get_messages_for_user(userID))


def get_messages_for_user(userID):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = (
            db_conn.execute(
                select(one_on_one_chat)
                .where(
                    or_(
                        one_on_one_chat.columns.senderID == userID,
                        one_on_one_chat.columns.recipientID == userID,
                    )
                )
                .order_by(one_on_one_chat.columns.timestamp)
            )
            .mappings()
            .all()
        )
        result = sql_result_to_json(result)

        other_rows = {}
        for row in result:
            if row["recipientID"] != userID:
                otherID = row["recipientID"]
            else:
                otherID = row["senderID"]

            if otherID not in other_rows:
                other_rows[otherID] = [row]
            else:
                other_rows[otherID].append(row)

        final_result = []
        for otherID, rows in other_rows.items():
            final_result.append(dict(otherID=otherID, rows=rows))

        return final_result


def get_one_interaction(userID, from_time, to_time):
    pool = get_pool()
    with pool.connect() as db_conn:
        # query='SELECT COUNT(timestamp) AS individual_interaction, senderID FROM one_on_one_chat WHERE(senderID={} and timestamp between {} and {}) ;'.format(userID,from_time,to_time)
        query = (
            select(
                func.count(one_on_one_chat.c.timestamp).label("individual_interaction")
                # ,one_on_one_chat.c.senderID
            )
            .where(
                (one_on_one_chat.c.senderID == userID)
                & (one_on_one_chat.c.timestamp.between(from_time, to_time))
            )
            .group_by(one_on_one_chat.c.senderID)
        )
        result = db_conn.execute(query)
        result = sql_result_to_json_cloud(result)
        other_rows = {}
        for row in result:
            if userID not in other_rows:
                other_rows[userID] = [row]
            else:
                other_rows[userID].append(row)

        final_result = []
        for otherValues, rows in other_rows.items():
            final_result.append(dict(UserID=otherValues, Values=rows))

        return dict(Features_Individual=final_result)


def get_one_interaction_single(userID):
    pool = get_pool()
    with pool.connect() as db_conn:
        # query='SELECT COUNT(timestamp) AS individual_interaction, senderID FROM one_on_one_chat WHERE(senderID={}) ;'.format(userID)
        query = (
            select(
                func.count(one_on_one_chat.c.timestamp).label("individual_interaction")
                # ,one_on_one_chat.c.senderID
            )
            .where((one_on_one_chat.c.senderID == userID))
            .group_by(one_on_one_chat.c.senderID)
        )
        result = db_conn.execute(query)
        result = sql_result_to_json_cloud(result)
        other_rows = {}
        for row in result:
            if userID not in other_rows:
                other_rows[userID] = [row]
            else:
                other_rows[userID].append(row)

        final_result = []
        for otherValues, rows in other_rows.items():
            final_result.append(dict(UserID=otherValues, Values=rows))

        return dict(Features_Individual=final_result)


def get_messages_for_user_and_other(userID, otherID):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = (
            db_conn.execute(
                select(one_on_one_chat)
                .where(
                    or_(
                        and_(
                            one_on_one_chat.columns.senderID == userID,
                            one_on_one_chat.columns.recipientID == otherID,
                        ),
                        and_(
                            one_on_one_chat.columns.senderID == otherID,
                            one_on_one_chat.columns.recipientID == userID,
                        ),
                    )
                )
                .order_by(one_on_one_chat.columns.timestamp)
            )
            .mappings()
            .all()
        )

        return sql_result_to_json(result)


if __name__ == "__main__":
    print(get_messages_for_user(1))
