import json
import string
from datetime import datetime, timedelta, timezone
import re

import nltk
import requests
import sqlalchemy.exc
import xmltodict
from bs4 import BeautifulSoup
from flask import Blueprint, jsonify, request
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    MetaData,
    String,
    Table,
    select,
    delete,
)
from sqlalchemy.dialects.mysql import insert
from sqlalchemy.orm import Session

from database import get_pool, sql_result_to_json

EventsJson = list[dict]

OLD_AGE_SUITABLE_QUERIES = [
    "senior",
    "for adult",
    "older adult",
    "all age",
    "elder",
    "18+",
    "14+",
]
# OLDER_ADULTS_QUERY_ADDITIONS = ["seniors", "old", "senior"]
OLDER_ADULTS_DEFAULT_QUERY = "seniors,old,senior"

events_blueprint = Blueprint("events_blueprint", __name__)

# from https://stackoverflow.com/a/3809435
URL_REGEX = "(https:\/\/www\.|http:\/\/www\.|https:\/\/|http:\/\/)?[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})(\.[a-zA-Z0-9]{2,})?"


events_table = Table(
    "events",
    MetaData(),
    Column("eventID", Integer, primary_key=True),
    Column("title", String),
    Column("description", String),
    Column("location", String),
    Column("startDateTime", DateTime),
    Column("endDateTime", DateTime),
    Column("eventImage", String),
    Column("age", String),
    Column("cost", String),
    Column("bookingURL", String)
)


user_event_history_table = Table(
    "user_event_history",
    MetaData(),
    Column("userID", Integer, primary_key=True),
    Column("eventID", Integer, primary_key=True),
)


@events_blueprint.route("/events/get")
def get_event():
    eventID = request.args.get("eventID")
    userID = request.args.get("userID")

    pool = get_pool()
    with pool.connect() as db_conn:
        if userID is None:
            result = (
                db_conn.execute(
                    select(events_table).where(events_table.columns.eventID == eventID)
                )
                .mappings()
                .all()
            )
            result = sql_result_to_json(result)

        else:
            result = (
                db_conn.execute(
                    select(events_table, user_event_history_table.columns.userID == userID)
                    .join(
                        user_event_history_table,
                        isouter=True,
                        onclause=(
                            events_table.columns.eventID == user_event_history_table.columns.eventID
                            and user_event_history_table.columns.userID == userID
                        )
                    )
                    .where(events_table.columns.eventID == eventID and user_event_history_table.userID == userID)
                ).mappings().all()
            )
            result = sql_result_to_json(result)
            for r in result:
                r["going"] = bool(r["anon_1"])  # true -> true;  null -> false
                r.pop("anon_1")

    if not result:
        return jsonify({})
    return jsonify(result[0])


@events_blueprint.route("/events/query", methods=["POST"])
def get_events_with_query():
    try:
        query = request.json["query"]
        num_return = int(request.json["num_return"])
    except KeyError as e:
        return (
            jsonify(
                {
                    "error_type": "Bad request",
                    "error_description": f"Missing field {e}",
                }
            ),
            400,
        )
    except Exception as e:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(e)}),
            400,
        )

    if "exclude" in request.json:
        excluded_event_ids = [int(id) for id in request.json["exclude"]]
    else:
        excluded_event_ids = None

    if "userID" in request.json:
        userID = request.json["userID"]
    else:
        userID = None

    if userID is None:
        events = event_query(query, num_return, excluded_event_ids)
    else:
        events = get_events_for_user(userID, num_return)

    return events


def load_brisbane_events(local=False) -> None:
    response = requests.get("http://www.trumba.com/calendars/brisbane-city-council.xml")

    events = xmltodict.parse(response.text)["feed"]["entry"]
    cleaned_events = []
    for event in events:
        try:
            desc_soup = BeautifulSoup(event["gc:notes"]["#text"], "html.parser")

            location = event["gd:where"]["@valueString"]
            if "gc:venueaddress" in event:
                location += "; " + event["gc:venueaddress"]["#text"]

            age = (
                f"{event['gc:age']['#text'] if 'gc:age' in event else ''}; "
                f"{event['gc:agerange']['#text'] if 'gc:agerange' in event else ''}"
            )

            # filter non-old-age
            old_age_suitable = False
            for query in OLD_AGE_SUITABLE_QUERIES:
                old_age_suitable |= query in age.lower()
            if not old_age_suitable:
                continue

            cleaned_events.append(
                {
                    "eventID": event["id"].split("/")[-1],
                    "title": event["title"]["#text"],
                    "description": desc_soup.text,
                    "location": location,
                    "startDateTime": event["gd:when"]["@startTime"].replace(
                        "Z", "+10:00"
                    ),
                    "endDateTime": event["gd:when"]["@endTime"].replace("Z", "+10:00"),
                    "eventImage": event["gc:eventimage"]["#text"],
                    "age": age,
                }
            )
            if "gc:cost" in event:
                cleaned_events[-1]["cost"] = event["gc:cost"]["#text"]
            if "gc:bookings" in event:
                url = re.search(URL_REGEX, event["gc:bookings"]["#text"])
                if url is not None:
                    cleaned_events[-1]["bookingURL"] = url[0]
        except KeyError as e:
            continue

    if local:
        with open("events.json", "w") as f:
            json.dump(cleaned_events, f)
    else:
        insert_events_into_database(cleaned_events)


def insert_events_into_database(events: list[dict]):
    pool = get_pool()
    with pool.connect() as db_conn:
        for event in events:
            insert_stmt = insert(events_table).values(**event)
            insert_stmt = insert_stmt.on_duplicate_key_update(**event)
            db_conn.execute(insert_stmt)
        db_conn.commit()


def get_all_next_events(userID=None):
    """gets all events from tomorrow"""
    tomorrow = (
        datetime.now(tz=timezone.utc) + timedelta(days=1) + timedelta(hours=10)
    )  # UTC TO AEST

    pool = get_pool()
    with pool.connect() as db_conn:
        if userID is None:
            result = (
                db_conn.execute(
                    select(events_table).where(
                        events_table.columns.startDateTime > tomorrow
                    )
                )
                .mappings()
                .all()
            )
            result = sql_result_to_json(result)

        else:
            result = (
                db_conn.execute(
                    select(events_table, user_event_history_table.columns.userID == userID)
                    .join(
                        user_event_history_table,
                        isouter=True,
                        onclause=events_table.columns.eventID == user_event_history_table.columns.eventID
                    )
                    .where(
                        events_table.columns.startDateTime > tomorrow
                    )
                ).mappings().all()
            )
            result = sql_result_to_json(result)
            for r in result:
                r["going"] = bool(r["anon_1"])  # true -> true;  null -> false
                r.pop("anon_1")

    return result


def get_event_corpus(events: EventsJson) -> list[list[str]]:
    corpus = []
    for event in events:
        event_corpus = []

        description = event["description"].lower()
        description = BeautifulSoup(description, "html.parser").text
        tokenized_description = description.split(" ")
        event_corpus.extend(tokenized_description)

        # for the old one
        if "customFields" in event:
            for custom_field in event["customFields"]:
                if "age" in custom_field["label"]:
                    event_corpus.extend(custom_field["value"].split(" "))

        if "age" in event:
            event_corpus.extend(event["age"].split(" "))

        corpus.append(event_corpus)
    return corpus


def init_bm25(events: EventsJson) -> BM25Okapi:
    corpus = get_event_corpus(events)
    return BM25Okapi(corpus)


def event_query(
    query: str,
    num_return: int = 5,
    excluded_event_ids: list[int] = None,
) -> EventsJson:
    if excluded_event_ids is None:
        excluded_event_ids = []
    if not query:
        query = OLDER_ADULTS_DEFAULT_QUERY

    events = get_all_next_events()
    bm25 = init_bm25(events)

    tokenized_query = query.lower().split(",")
    scores = bm25.get_scores(tokenized_query)

    # sort events by corresponding score
    sorted_events_with_scores = sorted(
        zip(events, scores), key=lambda pair: pair[1], reverse=True
    )
    sorted_events = [event for event, _ in sorted_events_with_scores]
    if len(sorted_events) < num_return:
        return {
            "error_type": "Bad request",
            "error_description": f"Can't find more than {len(sorted_events)} events",
        }, 400

    # filter events with the same name or in excluded_ids
    # and return num_return events
    seen_event_titles = []
    i = 0
    while i < num_return:
        if sorted_events[i]["title"] in seen_event_titles:
            sorted_events.pop(i)
        else:
            seen_event_titles.append(sorted_events[i]["title"])
            if sorted_events[i]["eventID"] in excluded_event_ids:
                sorted_events.pop(i)
            else:
                i += 1
    return sorted_events[:num_return]


def event_query_for_user(userID, num_return, excluded_event_ids=None):
    if excluded_event_ids is None:
        excluded_event_ids = []
    events = get_all_next_events(userID)
    bm25 = init_bm25(events)

    user_event_history = get_event_history(userID)
    user_event_descriptions = [event["description"].lower() for event in user_event_history]
    scores = bm25.get_scores(user_event_descriptions)

    if events[-1]["eventImage"].startswith("file"):
        scores[-1] += 10

    # sort events by corresponding score
    sorted_events_with_scores = sorted(
        zip(events, scores), key=lambda pair: pair[1], reverse=True
    )
    sorted_events = [event for event, _ in sorted_events_with_scores]
    if len(sorted_events) < num_return:
        return {
            "error_type": "Bad request",
            "error_description": f"Can't find more than {len(sorted_events)} events",
        }, 400

    # filter events with the same name or in excluded_ids
    # and return num_return events
    seen_event_titles = []
    i = 0
    while i < num_return:
        if sorted_events[i]["title"] in seen_event_titles:
            sorted_events.pop(i)
        else:
            seen_event_titles.append(sorted_events[i]["title"])
            if sorted_events[i]["eventID"] in excluded_event_ids:
                sorted_events.pop(i)
            else:
                i += 1
    return sorted_events[:num_return]


def get_events_for_user(userID, num_return):
    events = get_all_next_events(userID)
    user_event_history = get_event_history(userID)

    scores = recommendation_scores(user_event_history, events)

    if events[-1]["eventImage"].startswith("file"):
        scores[-1] += 10

    # sort events by corresponding score
    sorted_events_with_scores = sorted(
        zip(events, scores), key=lambda pair: pair[1], reverse=True
    )
    sorted_events = [event for event, _ in sorted_events_with_scores]
    if len(sorted_events) < num_return:
        return {
            "error_type": "Bad request",
            "error_description": f"Can't find more than {len(sorted_events)} events",
        }, 400

    # filter events with the same name or in excluded_ids
    # and return num_return events
    seen_event_titles = []
    i = 0
    while i < num_return:
        if sorted_events[i]["title"] in seen_event_titles:
            sorted_events.pop(i)
        else:
            seen_event_titles.append(sorted_events[i]["title"])
            i += 1
    return sorted_events[:num_return]



def recommendation_scores(past_events, new_events):
    scores = []
    for new_event in new_events:
        event_score = 0
        for past_event in past_events:
            event_score += similarity(past_event["description"], new_event["description"])
        scores.append(event_score)
    return scores


# modified from
# https://towardsdatascience.com/how-to-compute-text-similarity-on-a-website-with-tf-idf-in-python-680b3be06091
def similarity(description1, description2):
    # def preprocess(text):
    #     return nltk.word_tokenize(
    #         text.lower().translate(dict((ord(char), None) for char in string.punctuation))
    #     )
    #
    # nltk.download("stopwords")
    # stopwords = nltk.corpus.stopwords("english")
    #
    # vectorizer = TfidfVectorizer(preprocessor=preprocess, stop_words=stopwords)

    vectorizer = TfidfVectorizer()
    tfidf = vectorizer.fit_transform([description1.lower(), description2.lower()])
    return ((tfidf * tfidf.T).toarray())[0,1]


@events_blueprint.route("/events/add", methods=["POST"])
def add_event():
    try:
        age = request.json["age"]
        cost = request.json["cost"]
        description = request.json["description"]
        end_date_time = request.json["endDateTime"]
        event_image = request.json["eventImage"]
        location = request.json["location"]
        start_date_time = request.json["startDateTime"]
        title = request.json["title"]
    except KeyError as e:
        return jsonify(
            {
                "error_type": "Bad request",
                "error_description": f"Missing field {e}",
            }
        )
    except Exception as e:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(e)}),
            400,
        )

    event = dict(
        age=age,
        cost=cost,
        description=description,
        endDateTime=end_date_time,
        eventImage=event_image,
        location=location,
        startDateTime=start_date_time,
        title=title,
    )

    pool = get_pool()
    with Session(pool) as session:
        cursor = session.execute(insert(events_table).values(event))
        session.commit()
        return jsonify({"eventID": cursor.inserted_primary_key.eventID})


@events_blueprint.route("/events/history", methods=["POST"])
def event_history():
    ADD_MODE = "add"
    REMOVE_MODE = "remove"
    try:
        userID = request.json["userID"]
        eventID = request.json["eventID"]
        mode = request.json["mode"]
    except KeyError as ke:
        return (
            jsonify(
                {
                    "error_type": "Bad request",
                    "error_description": f"Missing field {ke}",
                }
            ),
            400,
        )
    except Exception as e:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(e)}),
            400,
        )

    if mode != ADD_MODE and mode != REMOVE_MODE:
        return (
            jsonify(
                {
                    "error_type": "Bad request",
                    "error_description": "Mode must be either `add` or `remove`",
                }
            ),
            400,
        )

    pool = get_pool()
    with pool.connect() as db_conn:
        if mode == ADD_MODE:
            insert_stmt = insert(user_event_history_table).values(
                userID=userID, eventID=eventID
            )
            try:
                db_conn.execute(insert_stmt)
            except sqlalchemy.exc.IntegrityError as ie:
                if "FOREIGN KEY" in ie.args[0]:
                    return (
                        jsonify(
                            {
                                "error_type": "Bad Request",
                                "error_message": f"eventID {eventID} does not exist",
                            }
                        ),
                        400,
                    )
                if "user_event_history.PRIMARY" in ie.args[0]:
                    return (
                        jsonify(
                            {
                                "error_type": "Bad Request",
                                "error_message": f"userID {userID} is already going to eventID {eventID}",
                            }
                        ),
                        400,
                    )
                return (
                    jsonify(
                        {
                            "error_type": "Bad Request",
                            "error_message": "I dont know what went wrong",
                        },
                    ),
                    400,
                )
            db_conn.commit()

        if mode == REMOVE_MODE:
            # check if userID & eventID pair doesn't exist
            values = db_conn.execute(
                select(user_event_history_table).where(
                    user_event_history_table.columns.userID == userID
                    and user_event_history_table.columns.eventID == eventID
                )
            )
            if values.rowcount == 0:
                return (
                    jsonify(
                        {
                            "error_type": "Bad Request",
                            "error_message": f"userID {userID} is not going to event {eventID}",
                        }
                    ),
                    400,
                )

            delete_stmt = delete(user_event_history_table).where(
                user_event_history_table.columns.userID == userID
                and user_event_history_table.columns.eventID == eventID
            )
            db_conn.execute(delete_stmt)
            db_conn.commit()

        return jsonify({"message": "success"}), 200


@events_blueprint.route("/events/history/visual", methods=["GET"])
def get_event_count():
    userID = request.args.get("userID")
    pool = get_pool()
    with Session(pool) as session:
        results = (
            session.query(
                sqlalchemy.func.month(events_table.columns.startDateTime),
                sqlalchemy.func.count(events_table.columns.eventID))
            .join(
                user_event_history_table,
                onclause=events_table.columns.eventID == user_event_history_table.columns.eventID
            )
            .where(user_event_history_table.columns.userID == userID)
            .where(events_table.columns.startDateTime > datetime.now() - timedelta(days=365))
            .group_by(sqlalchemy.func.month(events_table.columns.startDateTime))
            .all()
        )

        month_sorted_results = []
        for i in range(12):
            month = (datetime.now().month + i) % 12 + 1
            count = 0
            for result in results:
                if result[0] == month:
                    count = result[1]
                    break
            month_sorted_results.append(dict(month=month, count=count))

        return jsonify(month_sorted_results)


def get_event_history(userID: int):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = db_conn.execute(
            select(events_table)
            .join(
                user_event_history_table,
                onclause=user_event_history_table.columns.eventID == events_table.columns.eventID
            )
            .where(user_event_history_table.columns.userID == userID)
        ).mappings().all()

        result = sql_result_to_json(result)
        return result


if __name__ == "__main__":
    # load_brisbane_events()
    # recommendation_scores(get_event_history(1), get_all_next_events(1))
    ev = get_event_for_user(1, 100)