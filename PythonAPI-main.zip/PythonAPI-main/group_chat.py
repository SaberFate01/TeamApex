from flask import Blueprint, request, jsonify
import enum, datetime
from sqlalchemy import Enum, TIMESTAMP
from sqlalchemy import (
    insert,
    Table,
    MetaData,
    Column,
    Integer,
    DateTime,
    String,
    func,
    select,
    and_,
    or_,
)

from sqlalchemy.sql import null

from database import get_pool, sql_result_to_json, sql_result_to_json_cloud

group_chat_blueprint = Blueprint("group_chat_blueprint", __name__)


class EventType(enum.Enum):
    fun = "fun"
    event = "event"


group_chat = Table(
    "group_chat",
    MetaData(),
    Column("senderID", Integer, foreign_keys="one_on_one_chat.senderID"),
    Column("chatID", Integer, primary_key=True, autoincrement=True),
    Column("timestamp", TIMESTAMP, default=datetime.datetime.now),
    Column("message", String),
    Column("type", Enum(EventType)),
    Column("eventID", Integer),
    Column("chatRoom", Integer),
    Column("chatName", String),
)


@group_chat_blueprint.route("/group_chat/send", methods=["POST"])
def send_message():
    try:
        senderID = request.json["senderID"]
        timestamp = request.json["timestamp"]
        chatType = request.json["type"]
        chatRoom = request.json["chatRoom"]
        chatName = request.json["chatName"]
        type = None
        if chatType == "fun":
            type = EventType.fun
        else:
            type = EventType.event
    except KeyError as ke:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )

    if "message" in request.json:
        message = request.json["message"]
    else:
        message = null()
    if "eventID" in request.json:
        eventID = request.json["eventID"]
    else:
        eventID = null()

    pool = get_pool()
    with pool.connect() as db_conn:
        try:
            db_conn.execute(
                insert(group_chat).values(
                    dict(
                        senderID=senderID,
                        type=type,
                        chatRoom=chatRoom,
                        timestamp=timestamp,
                        message=message,
                        eventID=eventID,
                        chatName=chatName,
                    )
                )
            )
            db_conn.commit()
        except Exception as e:
            return (
                jsonify({"error_type": "Bad query", "error_description": str(e)}),
                400,
            )

    return ""


#############################################################################################
@group_chat_blueprint.route("/group_chat/get", methods=["POST"])
def get_messages():
    try:
        if (
            "chatRoom" not in request.json
            and "userID" not in request.json
            and "chatName" not in request.json
        ):
            raise KeyError()
    except KeyError as ke:
        return (
            jsonify({"error_type": "Bad request", "error_description": str(ke)}),
            400,
        )
    if "chatRoom" in request.json and "userID" in request.json:
        chatRoom = request.json["chatRoom"]
        userID = request.json["userID"]
        return jsonify(get_messages_specified(userID, chatRoom))
    elif "chatName" in request.json:
        return jsonify(get_room_name(request.json["chatName"]))
    elif "chatRoom" in request.json:
        return jsonify(get_room(request.json["chatRoom"]))
    else:
        return jsonify(get_messages_for_user(request.json["userID"]))


def get_messages_for_user(userID):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = (
            db_conn.execute(
                select(group_chat)
                .where(
                    or_(
                        group_chat.columns.senderID == userID,
                    )
                )
                .order_by(
                    group_chat.columns.timestamp,
                )
            )
            .mappings()
            .all()
        )
        result = sql_result_to_json(result)
        other_rows = {}
        for row in result:
            otherRoom = row["chatRoom"]
            if row["type"] == EventType.fun:
                row["type"] = "fun"
            else:
                row["type"] = "event"
            if otherRoom not in other_rows:
                other_rows[otherRoom] = [row]
            else:
                other_rows[otherRoom].append(row)

        final_result = []
        for otherRoom, rows in other_rows.items():
            final_result.append(dict(chatRoom=otherRoom, rows=rows))

        return dict(inter_chat=final_result)


def get_group_interaction_single(userID):
    pool = get_pool()
    with pool.connect() as db_conn:
        # query='SELECT COUNT(chatID) AS group_interaction,senderID FROM group_chat WHERE(senderID={}) ;'.format(userID)
        query = (
            select(
                func.count(group_chat.c.chatID).label("group_interaction")
                # ,group_chat.c.senderID
            )
            .where(group_chat.c.senderID == userID)
            .group_by(group_chat.c.senderID)
        )
        result = db_conn.execute(query)
        result = sql_result_to_json_cloud(result)
        other_rows = {}
        for row in result:
            if userID not in other_rows:
                other_rows[userID] = [row]
            else:
                other_rows[userID].append(row)

        final_result = []
        for otherValues, rows in other_rows.items():
            final_result.append(dict(UserID=otherValues, Values=rows))

        return dict(Features_Group=final_result)


def get_group_interaction(userID, from_time, to_time):
    pool = get_pool()
    with pool.connect() as db_conn:
        # query='SELECT COUNT(chatID) AS group_interaction,senderID FROM group_chat WHERE(senderID={} and timestamp between "{}" and "{}") ;'.format(userID,from_time,to_time)
        query = (
            select(
                func.count(group_chat.c.chatID).label("group_interaction")
                # ,group_chat.c.senderID
            )
            .where(
                (group_chat.c.senderID == userID)
                & (group_chat.c.timestamp.between(from_time, to_time))
            )
            .group_by(group_chat.c.senderID)
        )
        result = db_conn.execute(query)
        result = sql_result_to_json_cloud(result)
        other_rows = {}
        for row in result:
            if userID not in other_rows:
                other_rows[userID] = [row]
            else:
                other_rows[userID].append(row)

        final_result = []
        for otherValues, rows in other_rows.items():
            final_result.append(dict(UserID=otherValues, Values=rows))

        return dict(Features_Group=final_result)


def get_messages_specified(userID, Room):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = (
            db_conn.execute(
                select(group_chat)
                .where(
                    and_(
                        and_(
                            group_chat.columns.senderID == userID,
                        ),
                        and_(
                            group_chat.columns.chatRoom == Room,
                        ),
                    )
                )
                .order_by(
                    group_chat.columns.timestamp,
                )
            )
            .mappings()
            .all()
        )
        result = sql_result_to_json(result)
        other_rows = {}
        for row in result:
            otherRoom = row["chatRoom"]
            if row["type"] == EventType.fun:
                row["type"] = "fun"
            else:
                row["type"] = "event"
            if otherRoom not in other_rows:
                other_rows[otherRoom] = [row]
            else:
                other_rows[otherRoom].append(row)

        final_result = []
        for otherRoom, rows in other_rows.items():
            final_result.append(dict(chatRoom=otherRoom, rows=rows))

        return dict(inter_chat=final_result)


def get_room(Room):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = (
            db_conn.execute(
                select(group_chat)
                .where(
                    or_(
                        group_chat.columns.chatRoom == Room,
                    )
                )
                .order_by(
                    group_chat.columns.timestamp,
                )
            )
            .mappings()
            .all()
        )
        result = sql_result_to_json(result)
        other_rows = {}
        for row in result:
            Room = row["chatRoom"]
            if row["type"] == EventType.fun:
                row["type"] = "fun"
            else:
                row["type"] = "event"
            if Room not in other_rows:
                other_rows[Room] = [row]
            else:
                other_rows[Room].append(row)

        final_result = []
        for Room, rows in other_rows.items():
            final_result.append(dict(chatRoom=Room, rows=rows))

        return dict(Room=final_result)


def get_room_name(Name):
    pool = get_pool()
    with pool.connect() as db_conn:
        result = (
            db_conn.execute(
                select(group_chat)
                .where(
                    or_(
                        group_chat.columns.chatName == Name,
                    )
                )
                .order_by(
                    group_chat.columns.timestamp,
                )
            )
            .mappings()
            .all()
        )
        result = sql_result_to_json(result)
        other_rows = {}
        for row in result:
            Name = row["chatName"]
            if row["type"] == EventType.fun:
                row["type"] = "fun"
            else:
                row["type"] = "event"
            if Name not in other_rows:
                other_rows[Name] = [row]
            else:
                other_rows[Name].append(row)

        final_result = []
        for Name, rows in other_rows.items():
            final_result.append(dict(chatName=Name, rows=rows))

        return dict(Name=final_result)


if __name__ == "__main__":
    print(get_messages_for_user(1))
